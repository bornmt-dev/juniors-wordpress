<?php
/**
 * Silence is golden.
 *
 * @package Bzotech Framework
 */
